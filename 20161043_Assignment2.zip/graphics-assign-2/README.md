CONTROLS ::
KEY FOR CAMERA VIEWS::
	1 for follow cam view
	2 for boat view
	3 for top view
	4 for cannon view
	5 for tower view
	6 for helicopter view
	   --> In helicopter view click on left mouse button and drag it left and right for
	      controlling the disance (R) of cam from boat
	   --> In helicopter view click on right mouse button and drag it left and right for
	      controlling the angle of cam from boat
	   --> G AND H FUNCTION SIMILAR TO LEFT MOUSE BUTTON DRAG(RADIUS INCREMENT)
	   --> P AND M FUNCTION SIMILAR TO RIGHT MOUSE BUTTON DRAG(ANGLE CHANGE)
	No need to change view(done as inbuilt in code) when you step on land for viewing human as target.
KEY TO CHANGE PROJECTION::
	'o' FOR CHANGING BETWEEN ORTHO AND PERSPECTIVE(DEFAULT) 
KEYS TO CONTROL HUMAN MOVEMENT::
	W for moving ahead
	S for moving back
	A for moving left
	D for moving right
	R for getting human back into boat
	L for getting human onto land
KEYS TO MOVE CANNON::
	A for left
	D for right
	K for up
	J for down
	S for shoot 
	K and J for cannon up and down which were commented
KEYS TO MOVE BOAT::
	LEFT arrow key for left
	RIGHT arrow key for right
	UP arrow key for forward
	DOWN arrow key for backward
	SPACE key for jumping
IF SMALL ENEMIES DIE EACH OF THEM WILL LEAVE A GIFT AT THERE POSITION AND IF BIG ENEMY(BOSS) WHO APPEARS AFTER DESTRUCTION OF ATLEAST TWO SMALL ENEMIES DIES TO GIVE BOOSTERS SPLITTED ON THE SEA WHICH CAN BE COLLECTED AND KEPT FOR FUTURE USE

KEYS FOR BOOSTERS::
	B FOR USING BOOST
	N FOR STOPPING USE OF BOOST




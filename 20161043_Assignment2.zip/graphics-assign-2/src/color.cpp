#include "main.h"

const color_t COLOR_RED = { 236, 100, 75 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_BACKGROUND = { 135, 206, 250 };
const color_t COLOR_BROWN = {139,69,19};
const color_t COLOR_BASETOP = {205,133,63};
const color_t COLOR_BLUE = {28,163,236};
const color_t COLOR_DOM = {218,165,32};
const color_t COLOR_DOMEND = {105,105,105};
const color_t COLOR_WHITE = {255,255,255};
const color_t COLOR_WAVE = {64,224,208};
//35,127,218
//28,163,236
